"use strict";
/*
Cadin Marohl 11/29/2022
Hover over birds picture and it shows their name, click on the picture
and it shows a short description
*/

let george = document.getElementById("george");
let sophie = document.getElementById("sophie");
let reggie = document.getElementById("reggie");
let georgeCap = document.getElementById("georgeCap");
let sophieCap = document.getElementById("sophieCap");
let reggieCap = document.getElementById("reggieCap");

george.addEventListener("mouseenter", showGeorge);
george.addEventListener("mouseleave", clearCaption);

function showGeorge(){
    georgeCap.innerHTML += "<h2>George</h2>";
}

sophie.addEventListener("mouseenter", showSophie);
sophie.addEventListener("mouseleave", clearCaption);

function showSophie(){
    sophieCap.innerHTML += "<h2>Sophie</h2>";
}

reggie.addEventListener("mouseenter", showReggie);
reggie.addEventListener("mouseleave", clearCaption);

function showReggie(){
    reggieCap.innerHTML += "<h2>Reggie</h2>";
}

function clearCaption(){
    georgeCap.innerHTML = "";
    sophieCap.innerHTML = "";
    reggieCap.innerHTML = "";
}

